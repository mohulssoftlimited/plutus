window._env_ = {
        REACT_APP_BACKEND_URL: "PLACEHOLDER_BACKEND_URL"
        };
        